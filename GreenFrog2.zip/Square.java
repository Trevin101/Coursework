import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.Math;

public class Square implements ActionListener{
   
    private Board gui;
    private static JButton[][] button = new JButton[5][5];
    
    private int xpos;
    private int ypos;
    
    public static int tempX = -1, tempY = -1, typePasser = 0;
    private int currentType = 0;
    public static Component tempButton;

    private boolean JButtonSelected = false;
    
	ImageIcon LilyImg = new ImageIcon("LilyPad.png");
	ImageIcon RedFrogImg = new ImageIcon("RedFrog.png");
	ImageIcon RedFrog2Img = new ImageIcon("RedFrog2.png");   	
	ImageIcon GreenFrogImg = new ImageIcon("GreenFrog.png");
	ImageIcon GreenFrog2Img = new ImageIcon("GreenFrog2.png");
	ImageIcon WaterImg = new ImageIcon("Water.png");
    
    
    public Square(int n, int m, int type, Board gui) {
    	xpos = n;
    	ypos = m;
    	currentType = type;
    	
    	this.gui = gui;
    	
    	
    	if (type == 1) {
        	button[n][m] = new JButton(WaterImg);
        	button[n][m].addActionListener(this);
    	} if (type == 2){
    		button[n][m] = new JButton();
    		button[n][m].setIcon(GreenFrogImg);
    		button[n][m].addActionListener(this);
    	} if (type == 3){
    		button[n][m] = new JButton(RedFrogImg);
    		button[n][m].addActionListener(this);    		
    	} if (type == 4){
    		button[n][m] = new JButton(RedFrog2Img);
    		button[n][m].setIcon(RedFrog2Img);
    		button[n][m].addActionListener(this);    		
    	} if (type == 5){
    		button[n][m] = new JButton(GreenFrog2Img);
    		button[n][m].addActionListener(this);    		
    	}else if (type == -1 || type == 0) {
    		button[n][m] = new JButton(LilyImg);
        	button[n][m].addActionListener(this);
    	}	

 
    }
    
    public Component getButton() {
    	return button[xpos][ypos];
    }
    /** Used a function from research throught Stack Exchange
     * in order to clear the butttons from the game board
     */
    public static void boardClear() {
	    for (int i=0; i<5; i++) {
        	for (int j=0; j<5; j++) {
        		Container parent = button[i][j].getParent();
	        	parent.remove(Square.button[i][j]);
	        	parent.revalidate();
	        	parent.repaint();
        	}
        }
    }

    private void processClick(int x, int y, int z ) {
	   	System.out.println(tempX + " prev " + tempY);
	   	boardClear();
		gui.levelFrogSelector(x, y, tempX, z);
			
		

	   	
       	/**
       	 *        	if (tempX != -1) {
       		System.out.println((Square.button[x][y]).getIcon() + "");

	   		if (((Square.button[x][y]).getIcon() + "") == "GreenFrog.png") {
	   		   	System.out.println("work");

	   			(Square.button[tempX][tempY]).setIcon(GreenFrogImg);
	   		}
	   	} else {
	   		if (button[x][y].getIcon() == GreenFrogImg) {
	   			button[x][y].setIcon(GreenFrog2Img);
	   		} else if (button[x][y].getIcon() == RedFrogImg) {
	   			button[x][y].setIcon(RedFrog2Img);
	   		}
	   	}
   		
       	System.out.println("  " );
       	 * 
	   	 * 
	   	tempButton = getButton();
	   	if (tempX != -1) {
	   		
	   	} else {
	   		if (button[x][y].getIcon() == GreenFrogImg) {
	   			
	   			button[x][y].setIcon(GreenFrog2Img);
	   			((AbstractButton) tempButton).setIcon(RedFrog2Img);
	   		} else if (button[x][y].getIcon() == RedFrogImg) {
	   			button[x][y].setIcon(RedFrog2Img);
	   		}
	   	}
	   	
	   	for (int i=0; i<5; i++) {
        	for (int j=0; j<5; j++) {
        		
        		Container parent = button[3][3].getParent();
			   	parent.remove(button[3][3]);
			   	parent.revalidate();
			   	parent.repaint();
			   	
        		}
        	}

	   			typePasser = z;
	   	
**/

    	


    	tempX = x;
    	
	  }




	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		  System.out.println(currentType);
	      processClick(xpos,ypos, currentType);
		     /**
	        			     
	          * 		   	(Square.button[3][3]).setIcon(RedFrog2Img);
	          * 

		   		        		parent.remove(button[3][3]);
	        		parent.revalidate();
	        		parent.repaint();
	
		   		





			
			gui.digitHit(xpos,ypos); **/

	}
}


