import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.Math;

public class GameBoard extends JFrame{
	
}
